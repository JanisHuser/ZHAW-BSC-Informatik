import numpy as np
from numbers import Number


class Jacobi():
    def __init__(self, A, b, x0):
        self._A = A
        self._b = b
        self._x = [x0]
    
    def x_len(self) -> Number:
        return len(self._x)
        
    def get_x(self, index: Number) -> np.array:
        return self._x[index]
        
    def decomposite_A(self):
        '''
        Create decomposite of A
        returns [D, D_inv, L, R]
        '''
        D = np.diag(np.diag(self._A))
        D_inv = np.linalg.inv(D)
        L = np.tril(self._A, -1)
        R = np.triu(self._A, 1)

        return [D, D_inv, L, R]
        
    def calc_B(self) -> np.array:
        [D, D_inv, L, R] = self.decomposite_A()
        B = np.dot(-1, D_inv.dot(np.add(L, R)))
        return B
        
    def calc_xn(self, x):
        [D, D_inv, L, R] = self.decomposite_A()
        B = self.calc_B()
        
        return np.add(B.dot(x), D_inv.dot(self._b))
        
        
    def calc_a_posteriori_error(self,B, x, xn) -> Number:
        B_norm = np.linalg.norm(B, np.inf)
        x_norm = np.linalg.norm(xn - x, np.inf)

        err = (B_norm / (1 - B_norm)) * x_norm

        return err
        
    def estimate_a_priori(self, tol) -> Number:
        
        order = 1
        x0 = self._x[0]
        x1 = self.calc_xn(x0)
        
        B = self.calc_B()
        B_norm = np.linalg.norm(B, 1)
        x_norm = np.linalg.norm(x1 - x0, 1)

        n = np.log(((1 - B_norm) / x_norm) * tol) / np.log(B_norm)

        return n
    
    
        
    def iterate(self, tolerance=-1, log: bool = False):
        i = 0
        B = self.calc_B()
        
        if log:
            print(f"{i}.Iteration")
            print(self._x[i])
        
        while True:
            
            x = self._x[i]
            xn = self.calc_xn(x)
            self._x.append(xn)
            
            err = self.calc_a_posteriori_error(B, x, xn)
            i += 1
            
            if log:
                print(f"{i}.Iteration")
                print(self._x[i])
                print(f"A posteriori: {err}")
            
            if err <= tolerance:
                break
            
        
        return (i, x)  


x0 = np.array([-1, -1, 1, 1]).reshape(4,1)
tolerance = 10**(-3)
alpha = 0.3

A = np.array([
    [1, alpha, 0, -alpha],
    [alpha, 1, -alpha, 0],
    [0, -alpha, 1, alpha],
    [-alpha, 0, alpha, 1]
])

b = np.array([
    [2.3],
    [-1.3],
    [2.7],
    [-1.7]
])

jacobi = Jacobi(
    A,
    b,
    x0)


print ("Aufgabe 5")


estimation = jacobi.estimate_a_priori(tolerance)
print (f"A-Priori abschätzung: {estimation}  => {round(estimation)}")

iterations, result = jacobi.iterate(tolerance, False)

print ("Iterationen gebraucht:", iterations)
print ("Resultat x", result)

# def calc_a_posteriori_error(self,B, x, xn) -> Number: